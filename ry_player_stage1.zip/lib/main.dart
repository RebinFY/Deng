import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:on_audio_query/on_audio_query.dart';

final player = AudioPlayer();
final query = OnAudioQuery();

const bg = Color(0xFF0B0B10);
const card = Color(0xFF17171F);
const accent = Color(0xFFFF3D6E);
const grad = LinearGradient(colors: [Color(0xFFFF3D6E), Color(0xFF7B4DFF)]);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await JustAudioBackground.init(
    androidNotificationChannelId: 'com.aram.ry_player.audio',
    androidNotificationChannelName: 'RY Player',
    androidNotificationOngoing: true,
  );
  runApp(const DengApp());
}

class DengApp extends StatelessWidget {
  const DengApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'RY Player',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: bg,
          colorScheme: const ColorScheme.dark(primary: accent, surface: card),
        ),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const LocalPage(), const Center(child: Text('گەڕانی یوتوب — بەم زووانە')), const Center(child: Text('کتێبخانە — بەم زووانە'))];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
        const MiniPlayer(),
        NavigationBar(
          backgroundColor: card,
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_rounded), label: 'سەرەکی'),
            NavigationDestination(icon: Icon(Icons.search_rounded), label: 'گەڕان'),
            NavigationDestination(icon: Icon(Icons.library_music_rounded), label: 'کتێبخانە'),
          ],
        ),
      ]),
    );
  }
}

class LocalPage extends StatefulWidget {
  const LocalPage({super.key});
  @override
  State<LocalPage> createState() => _LocalPageState();
}

class _LocalPageState extends State<LocalPage> {
  late Future<List<SongModel>> songs = _load();

  Future<List<SongModel>> _load() async {
    if (!await query.permissionsStatus()) {
      if (!await query.permissionsRequest()) return [];
    }
    return query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );
  }

  Future<void> _play(List<SongModel> list, int i) async {
    final src = ConcatenatingAudioSource(
      children: list
          .map((s) => AudioSource.uri(Uri.parse(s.uri!),
              tag: MediaItem(id: '${s.id}', title: s.title, artist: s.artist ?? 'نەزانراو')))
          .toList(),
    );
    await player.setAudioSource(src, initialIndex: i);
    player.play();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
        child: Row(children: [
          Image.asset('assets/logo.png', width: 40, height: 40),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (r) => grad.createShader(r),
            child: const Text('RY Player', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.white)),
          ),
        ]),
      ),
      const Padding(padding: EdgeInsets.fromLTRB(20, 8, 20, 8), child: Text('گۆرانییەکانی مۆبایل', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600))),
      Expanded(
        child: FutureBuilder<List<SongModel>>(
          future: songs,
          builder: (c, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final list = snap.data!;
            if (list.isEmpty) return const Center(child: Text('هیچ گۆرانییەک نەدۆزرایەوە'));
            return ListView.builder(
              itemCount: list.length,
              itemBuilder: (c, i) => ListTile(
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: QueryArtworkWidget(id: list[i].id, type: ArtworkType.AUDIO, artworkWidth: 50, artworkHeight: 50, nullArtworkWidget: Container(width: 50, height: 50, color: card, child: const Icon(Icons.music_note))),
                ),
                title: Text(list[i].title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(list[i].artist ?? 'نەزانراو', maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () => _play(list, i),
              ),
            );
          },
        ),
      ),
    ]);
  }
}

MediaItem? _item(SequenceState? s) => s?.currentSource?.tag as MediaItem?;

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<SequenceState?>(
      stream: player.sequenceStateStream,
      builder: (c, snap) {
        final m = _item(snap.data);
        if (m == null) return const SizedBox.shrink();
        return GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NowPlaying())),
          child: Container(
            margin: const EdgeInsets.fromLTRB(8, 0, 8, 6),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(16)),
            child: Row(children: [
              const Icon(Icons.graphic_eq, color: accent),
              const SizedBox(width: 12),
              Expanded(child: Text(m.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
              const PlayButton(size: 30),
            ]),
          ),
        );
      },
    );
  }
}

class PlayButton extends StatelessWidget {
  final double size;
  const PlayButton({super.key, this.size = 40});
  @override
  Widget build(BuildContext context) => StreamBuilder<bool>(
        stream: player.playingStream,
        builder: (c, s) {
          final playing = s.data ?? false;
          return IconButton(
            iconSize: size,
            icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded),
            onPressed: () => playing ? player.pause() : player.play(),
          );
        },
      );
}

class NowPlaying extends StatelessWidget {
  const NowPlaying({super.key});
  String _fmt(Duration d) => '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(backgroundColor: Colors.transparent, leading: IconButton(icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32), onPressed: () => Navigator.pop(context))),
      body: StreamBuilder<SequenceState?>(
        stream: player.sequenceStateStream,
        builder: (c, snap) {
          final m = _item(snap.data);
          if (m == null) return const SizedBox.shrink();
          return Padding(
            padding: const EdgeInsets.all(28),
            child: Column(children: [
              Expanded(
                child: Center(
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: QueryArtworkWidget(id: int.parse(m.id), type: ArtworkType.AUDIO, artworkWidth: 400, artworkHeight: 400, artworkFit: BoxFit.cover, size: 800,
                          nullArtworkWidget: Container(decoration: const BoxDecoration(gradient: grad), child: const Icon(Icons.music_note_rounded, size: 120, color: Colors.white))),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(m.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(m.artist ?? '', style: const TextStyle(color: Colors.white60)),
              StreamBuilder<Duration?>(
                stream: player.durationStream,
                builder: (c, d) {
                  final total = d.data ?? Duration.zero;
                  return StreamBuilder<Duration>(
                    stream: player.positionStream,
                    builder: (c, p) {
                      final pos = p.data ?? Duration.zero;
                      final max = total.inMilliseconds.toDouble();
                      return Column(children: [
                        Directionality(
                          textDirection: TextDirection.ltr,
                          child: Slider(
                            value: pos.inMilliseconds.clamp(0, max <= 0 ? 1 : max).toDouble(),
                            max: max <= 0 ? 1 : max,
                            onChanged: (v) => player.seek(Duration(milliseconds: v.toInt())),
                          ),
                        ),
                        Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_fmt(pos)), Text(_fmt(total))])),
                      ]);
                    },
                  );
                },
              ),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(iconSize: 40, icon: const Icon(Icons.skip_next_rounded), onPressed: player.seekToNext),
                Container(decoration: const BoxDecoration(gradient: grad, shape: BoxShape.circle), child: const PlayButton(size: 48)),
                IconButton(iconSize: 40, icon: const Icon(Icons.skip_previous_rounded), onPressed: player.seekToPrevious),
              ]),
              const SizedBox(height: 16),
            ]),
          );
        },
      ),
    );
  }
}
