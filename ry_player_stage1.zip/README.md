# RY Player — قۆناغی ١

1. هەموو فایلەکان بکە بە repo ی GitHub (فۆڵدەری `.github` یش).
2. بڕۆ بۆ **Actions** ← **Build APK** ← کۆتایی کار ← **Artifacts** ← `RY-Player-apk`.
3. APKـەکە دابگرە و لەسەر مۆبایل دایبمەزرێنە.
