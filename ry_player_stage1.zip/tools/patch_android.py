import re, pathlib
root = pathlib.Path('android/app')
# manifest
mp = root/'src/main/AndroidManifest.xml'
m = mp.read_text(encoding='utf-8')
perms = '''    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
'''
m = re.sub(r'(<manifest[^>]*>\n)', lambda x: x.group(1)+perms, m, count=1)
svc = '''        <service android:name="com.ryanheise.audioservice.AudioService" android:foregroundServiceType="mediaPlayback" android:exported="true">
            <intent-filter><action android:name="android.media.browse.MediaBrowserService"/></intent-filter>
        </service>
        <receiver android:name="com.ryanheise.audioservice.MediaButtonReceiver" android:exported="true">
            <intent-filter><action android:name="android.intent.action.MEDIA_BUTTON"/></intent-filter>
        </receiver>
'''
m = m.replace('</application>', svc+'    </application>', 1)
m = re.sub(r'android:label="[^"]*"', 'android:label="RY Player"', m, count=1)
mp.write_text(m, encoding='utf-8')
# MainActivity
for f in (root/'src/main').rglob('MainActivity.*'):
    txt = f.read_text(encoding='utf-8')
    txt = txt.replace('FlutterActivity', 'com.ryanheise.audioservice.AudioServiceActivity')
    txt = txt.replace('import io.flutter.embedding.android.com.ryanheise.audioservice.AudioServiceActivity\n', '')
    f.write_text(txt, encoding='utf-8')
# minSdk
for g in (root/'build.gradle', root/'build.gradle.kts'):
    if g.exists():
        t = g.read_text(encoding='utf-8')
        t = re.sub(r'minSdk(Version)?\s*=?\s*(flutter\.minSdkVersion|\d+)', 'minSdk = 23', t)
        g.write_text(t, encoding='utf-8')
